﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Covid
{
    public class SARSCov2
    {
        private readonly List<COVID19gdw> covidData;

        public SARSCov2(string fileName)
        {
            covidData = LoadDataFromFile(fileName);
        }

        public List<COVID19gdw> GetCovidDataForPolandSortedByDate()
        {
            var polandData = covidData
                .Where(data => data.CountriesAndTerritories == "Poland")
                .OrderBy(data => data.DateRep)
                .ToList();

            return polandData;
        }

        public List<string> GetAvailableCountries()
        {
            var distinctCountries = covidData
                .Select(data => data.CountriesAndTerritories)
                .Distinct()
                .ToList();

            return distinctCountries;
        }

        public List<COVID19gdw> GetCovidDataForCountrySortedByDate(string country)
        {
            var countryData = covidData
                .Where(data => data.CountriesAndTerritories == country)
                .OrderBy(data => data.DateRep)
                .ToList();

            return countryData;
        }

        public int GetTotalCasesForCountry(string country)
        {
            int totalCases = covidData
                .Where(data => data.CountriesAndTerritories == country)
                .Sum(data => data.Cases);

            return totalCases;
        }

        public List<CovidSummary> GetCovidSummaryForCountry(string country)
        {
            var countryData = GetCovidDataForCountrySortedByDate(country);
            var covidSummaryList = new List<CovidSummary>();

            foreach (var data in countryData)
            {
                var summary = new CovidSummary
                {
                    DateRep = data.DateRep,
                    Cases = data.Cases,
                    Deaths = data.Deaths
                };
                covidSummaryList.Add(summary);
            }

            return covidSummaryList;
        }

        public List<COVID19gdw> GetCovidData()
        {
            return covidData;
        }

        private List<COVID19gdw> LoadDataFromFile(string fileName)
        {
            fileName = "COVID-19-geographic-disbtribution-worldwide.csv";
            List<COVID19gdw> lista = new List<COVID19gdw>();
            if (File.Exists(fileName) == false)
            {
                Console.WriteLine("Brak danych. Brak pliku {0}!", fileName);
                return null;
            }
            using (StreamReader srd = new StreamReader(fileName))
            {
                string linia = srd.ReadLine();
                string[] tab;
                COVID19gdw covid;
                while ((linia = srd.ReadLine()) != null)
                {
                    tab = linia.Split(';');
                    try
                    {
                        covid = new COVID19gdw()
                        {
                            DateRep = new DateTime(int.Parse(tab[3]), int.Parse(tab[2]), int.Parse(tab[1])),
                            Day = int.Parse(tab[1]),
                            Month = int.Parse(tab[2]),
                            Year = int.Parse(tab[3]),
                            Cases = int.Parse(tab[4]),
                            Deaths = int.Parse(tab[5]),
                            CountriesAndTerritories = tab[6],
                            GeoId = tab[7],
                            CountryterritoryCode = tab[8],
                            PopData2019 = tab[9] != "" ? int.Parse(tab[9]) : -1,
                            ContinentExp = tab[10],
                            CumulativeNumber = tab[11] != "" ? double.Parse(tab[11]) : -1
                        };
                        lista.Add(covid);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        foreach (var item in tab)
                        {
                            Console.Write("{0}, ", item);
                        }
                        Console.WriteLine();
                        Console.ReadKey();
                    }
                }
            }
            Console.WriteLine("Liczba wczytanych rekordów: {0}", lista.Count);
            return lista;
        }
    }
}
