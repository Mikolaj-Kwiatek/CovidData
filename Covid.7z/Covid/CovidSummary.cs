﻿using System;

namespace Covid
{
    public class CovidSummary
    {
        public DateTime DateRep { get; set; }
        public int Cases { get; set; }
        public int Deaths { get; set; }

        public override string ToString()
        {
            return $"DateRep: {DateRep.ToString("yyyy-MM-dd")}, Cases: {Cases}, Deaths: {Deaths}";
        }
    }
}
