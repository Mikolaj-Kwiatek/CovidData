﻿using System;
using System.Text;

namespace Covid
{
    public class COVID19gdw
    {
        public DateTime DateRep { get; set; }
        public int Day { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public int Cases { get; set; }
        public int Deaths { get; set; }
        public string CountriesAndTerritories { get; set; }
        public string GeoId { get; set; }
        public string CountryterritoryCode { get; set; }
        public int PopData2019 { get; set; }
        public string ContinentExp { get; set; }
        public double CumulativeNumber { get; set; }

        public override string ToString()
        {
            StringBuilder tmp = new StringBuilder();
            tmp.Append("DateRep: ").Append(DateRep.ToString("yyyy-MM-dd")).Append(", ");
            tmp.Append("Cases: ").Append(Cases).Append(", ");
            tmp.Append("Deaths: ").Append(Deaths).Append(", ");
            tmp.Append("CountriesAndTerritories: ").Append(CountriesAndTerritories).Append(", ");
            tmp.Append("GeoId: ").Append(GeoId).Append(", ");
            tmp.Append("CountryterritoryCode: ").Append(CountryterritoryCode).Append(", ");
            tmp.Append("PopData2019: ").Append(PopData2019).Append(", ");
            tmp.Append("ContinentExp: ").Append(ContinentExp).Append(", ");
            tmp.Append("CumulativeNumber: ").Append(CumulativeNumber);

            return tmp.ToString();
        }
    }
}
