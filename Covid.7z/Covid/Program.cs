﻿using System;

namespace Covid
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string fileName = "COVID-19-geographic-disbtribution-worldwide.csv";
            string selectedCountry = "Poland";
            SARSCov2 sarsCov2 = new SARSCov2(fileName);
            

            // Podpunkt a) i podpunkt c) to to samo tylko w parametrze funkcji trzeba wpisać inny dostępny kraj
            Console.WriteLine("\nDane dotyczące COVID-19 dla Polski:");
            foreach (var item in sarsCov2.GetCovidDataForCountrySortedByDate(selectedCountry))
            {
                Console.WriteLine(item.ToString());
            }

            // Podpunkt b)
            Console.WriteLine("Dostępne kraje/regiony:");
            foreach (var country in sarsCov2.GetAvailableCountries())
            {
                Console.WriteLine(country);
            }

            // Podpunkt d)
            int totalCases = sarsCov2.GetTotalCasesForCountry(selectedCountry);
            Console.WriteLine($"\nSuma przypadków COVID-19 dla {selectedCountry}: {totalCases}");

            //Podpunkt e)
            Console.WriteLine("\nInformacje dotyczące COVID-19 dla Polski:");
            foreach (var summary in sarsCov2.GetCovidSummaryForCountry(selectedCountry))
            {
                Console.WriteLine(summary.ToString());
            }

            Console.ReadKey();
        }
    }
}
